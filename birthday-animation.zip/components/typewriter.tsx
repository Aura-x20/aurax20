"use client"

import { useEffect, useState } from "react"

/** Reveals an array of lines one character at a time, line after line. */
export function Typewriter({
  lines,
  speed = 55,
  lineDelay = 600,
  onDone,
  className = "",
  lineClassName = "",
}: {
  lines: string[]
  speed?: number
  lineDelay?: number
  onDone?: () => void
  className?: string
  lineClassName?: string
}) {
  const [done, setDone] = useState<string[]>([])
  const [current, setCurrent] = useState("")
  const [lineIdx, setLineIdx] = useState(0)
  const [charIdx, setCharIdx] = useState(0)

  useEffect(() => {
    if (lineIdx >= lines.length) {
      onDone?.()
      return
    }
    const line = lines[lineIdx]
    if (charIdx < line.length) {
      const t = setTimeout(() => {
        setCurrent(line.slice(0, charIdx + 1))
        setCharIdx((c) => c + 1)
      }, speed)
      return () => clearTimeout(t)
    }
    // line finished
    const t = setTimeout(() => {
      setDone((d) => [...d, line])
      setCurrent("")
      setCharIdx(0)
      setLineIdx((l) => l + 1)
    }, lineDelay)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [charIdx, lineIdx, lines])

  return (
    <div className={className}>
      {done.map((l, i) => (
        <p key={i} className={lineClassName}>
          {l}
        </p>
      ))}
      {lineIdx < lines.length && (
        <p className={lineClassName}>
          {current}
          <span className="ml-0.5 inline-block w-0.5 animate-pulse text-gold">|</span>
        </p>
      )}
    </div>
  )
}
