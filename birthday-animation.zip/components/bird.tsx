"use client"

import { motion } from "motion/react"

/** A simple, elegant flying bird rendered with SVG + flapping wings. */
export function Bird({
  className = "",
  size = 64,
  tone = "gold",
}: {
  className?: string
  size?: number
  tone?: "gold" | "amber"
}) {
  const body = tone === "gold" ? "var(--gold)" : "var(--gold-deep)"
  const wing = tone === "gold" ? "var(--gold-soft)" : "var(--gold)"

  return (
    <div
      className={className}
      style={{ width: size, height: size }}
      aria-hidden="true"
    >
      <svg viewBox="0 0 100 100" width={size} height={size}>
        <defs>
          <filter id="birdGlow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="1.6" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
        {/* body */}
        <ellipse cx="50" cy="56" rx="14" ry="9" fill={body} filter="url(#birdGlow)" />
        {/* head */}
        <circle cx="63" cy="50" r="7" fill={body} />
        {/* beak */}
        <path d="M70 49 L78 51 L70 53 Z" fill="var(--gold-soft)" />
        {/* tail */}
        <path d="M36 56 L24 50 L30 58 L24 64 Z" fill={body} />
        {/* left wing */}
        <motion.path
          d="M48 52 Q40 30 26 28 Q42 40 46 54 Z"
          fill={wing}
          style={{ transformOrigin: "48px 54px" }}
          animate={{ rotate: [0, -28, 0], scaleY: [1, 0.7, 1] }}
          transition={{ duration: 0.6, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
        />
        {/* right wing */}
        <motion.path
          d="M52 52 Q60 30 74 28 Q58 40 54 54 Z"
          fill={wing}
          style={{ transformOrigin: "52px 54px" }}
          animate={{ rotate: [0, 28, 0], scaleY: [1, 0.7, 1] }}
          transition={{ duration: 0.6, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
        />
        {/* eye */}
        <circle cx="65" cy="48" r="1.4" fill="var(--background)" />
      </svg>
    </div>
  )
}
