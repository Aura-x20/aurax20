"use client"

import { useMemo } from "react"
import { motion } from "motion/react"

/** A radial burst of golden sparkles used for celebratory transitions. */
export function SparkleBurst({
  count = 28,
  className = "",
}: {
  count?: number
  className?: string
}) {
  const sparks = useMemo(
    () =>
      Array.from({ length: count }).map((_, i) => {
        const angle = (i / count) * Math.PI * 2
        const dist = 120 + Math.random() * 180
        return {
          id: i,
          x: Math.cos(angle) * dist,
          y: Math.sin(angle) * dist,
          size: 3 + Math.random() * 6,
          delay: Math.random() * 0.15,
        }
      }),
    [count],
  )

  return (
    <div
      className={`pointer-events-none absolute inset-0 flex items-center justify-center ${className}`}
      aria-hidden="true"
    >
      {sparks.map((s) => (
        <motion.span
          key={s.id}
          className="absolute rounded-full bg-gold"
          style={{
            width: s.size,
            height: s.size,
            boxShadow: "0 0 12px 2px var(--gold-soft)",
          }}
          initial={{ x: 0, y: 0, opacity: 1, scale: 1 }}
          animate={{ x: s.x, y: s.y, opacity: 0, scale: 0.2 }}
          transition={{ duration: 1.1, delay: s.delay, ease: "easeOut" }}
        />
      ))}
    </div>
  )
}
