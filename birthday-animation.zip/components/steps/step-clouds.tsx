"use client"

import { useMemo } from "react"
import { motion } from "motion/react"
import { Bird } from "@/components/bird"
import { ContinueHint } from "@/components/continue-hint"

export function StepClouds({ onComplete }: { onComplete: () => void }) {
  const clouds = useMemo(
    () =>
      Array.from({ length: 7 }).map((_, i) => ({
        id: i,
        top: 8 + Math.random() * 78,
        size: 90 + Math.random() * 150,
        delay: Math.random() * 6,
        duration: 14 + Math.random() * 12,
        heart: i % 2 === 0,
      })),
    [],
  )

  return (
    <button
      onClick={onComplete}
      className="relative flex min-h-dvh w-full cursor-pointer items-center justify-center overflow-hidden no-select"
      style={{
        background:
          "linear-gradient(180deg, oklch(0.55 0.08 80) 0%, oklch(0.7 0.09 85) 40%, oklch(0.85 0.07 90) 100%)",
      }}
      aria-label="Continue through the clouds"
    >
      {/* sun glow */}
      <div
        className="pointer-events-none absolute left-1/2 top-1/3 h-72 w-72 -translate-x-1/2 rounded-full opacity-70 blur-2xl"
        style={{ background: "radial-gradient(circle, oklch(0.97 0.12 95), transparent 70%)" }}
      />

      {clouds.map((c) => (
        <motion.div
          key={c.id}
          className="pointer-events-none absolute"
          style={{ top: `${c.top}%` }}
          initial={{ x: "110vw" }}
          animate={{ x: "-40vw" }}
          transition={{
            duration: c.duration,
            delay: c.delay,
            repeat: Number.POSITIVE_INFINITY,
            ease: "linear",
          }}
        >
          {c.heart ? <HeartCloud size={c.size} /> : <Cloud size={c.size} />}
        </motion.div>
      ))}

      {/* bird POV */}
      <motion.div
        animate={{ y: [0, -16, 0] }}
        transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
        className="absolute bottom-24 z-10"
      >
        <Bird size={70} tone="amber" />
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.6, duration: 1.2 }}
        className="relative z-20 px-6 text-center"
      >
        <p className="text-balance font-script text-3xl text-[oklch(0.32_0.06_55)] drop-shadow-[0_2px_8px_rgba(255,255,255,0.5)] md:text-4xl">
          You make the sky feel like home
        </p>
      </motion.div>

      <ContinueHint label="click to keep flying" />
    </button>
  )
}

function Cloud({ size }: { size: number }) {
  return (
    <svg width={size} height={size * 0.62} viewBox="0 0 200 124" fill="oklch(0.98 0.02 95)">
      <ellipse cx="60" cy="80" rx="55" ry="38" />
      <ellipse cx="110" cy="70" rx="60" ry="46" />
      <ellipse cx="150" cy="84" rx="45" ry="34" />
      <rect x="40" y="80" width="130" height="40" rx="20" />
    </svg>
  )
}

function HeartCloud({ size }: { size: number }) {
  return (
    <svg width={size} height={size * 0.9} viewBox="0 0 24 22" fill="oklch(0.97 0.04 92)">
      <path d="M12 21s-7.5-4.9-10-9.3C.5 8.3 2 5 5.2 5c2 0 3.2 1.2 3.9 2.4C9.8 6.2 11 5 13 5c3.2 0 4.7 3.3 3.2 6.7C18.5 16.1 12 21 12 21z" />
    </svg>
  )
}
