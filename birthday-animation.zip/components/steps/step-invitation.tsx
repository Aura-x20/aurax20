"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "motion/react"
import { GoldenParticles } from "@/components/golden-particles"
import { ContinueHint } from "@/components/continue-hint"

export function StepInvitation({ onComplete }: { onComplete: () => void }) {
  const [open, setOpen] = useState(false)

  return (
    <button
      onClick={() => (open ? onComplete() : setOpen(true))}
      className="relative flex min-h-dvh w-full cursor-pointer items-center justify-center overflow-hidden bg-background text-left vignette no-select"
      aria-label={open ? "Continue" : "Open the invitation"}
    >
      <GoldenParticles count={26} />

      <div className="relative z-10 flex w-full max-w-md flex-col items-center px-6">
        {/* Envelope */}
        <div className="relative" style={{ perspective: 1200 }}>
          {/* letter rising fully above the envelope (not clipped) */}
          <AnimatePresence>
            {open && (
              <motion.div
                initial={{ y: 40, opacity: 0, scale: 0.9 }}
                animate={{ y: -150, opacity: 1, scale: 1 }}
                transition={{ duration: 1.2, delay: 0.5, ease: "easeOut" }}
                className="absolute inset-x-2 bottom-6 z-40 rounded-md bg-[oklch(0.95_0.03_92)] p-5 text-center shadow-2xl"
              >
                <p className="font-script text-lg leading-relaxed text-[oklch(0.32_0.05_60)]">
                  13/06 — not just a date.
                  <br />
                  It&apos;s the day the universe made someone so sweet, even the stars whispered,
                  <br />
                  <span className="text-[oklch(0.5_0.13_55)]">
                    &ldquo;There goes Jaanu.&rdquo;
                  </span>
                </p>
              </motion.div>
            )}
          </AnimatePresence>

          {/* envelope back / body */}
          <div className="relative h-64 w-80 max-w-[88vw] overflow-hidden rounded-lg border border-gold/40 bg-gradient-to-b from-[oklch(0.3_0.05_75)] to-[oklch(0.22_0.04_70)] shadow-[0_0_60px_-10px_var(--gold)]">
            {/* envelope flap */}
            <motion.div
              initial={false}
              animate={open ? { rotateX: 180 } : { rotateX: 0 }}
              transition={{ duration: 0.9, ease: "easeInOut" }}
              style={{ transformOrigin: "top", transformStyle: "preserve-3d" }}
              className="absolute inset-x-0 top-0 z-30 h-32 origin-top"
            >
              <div
                className="h-full w-full"
                style={{
                  clipPath: "polygon(0 0, 100% 0, 50% 100%)",
                  background:
                    "linear-gradient(180deg, oklch(0.42 0.08 80), oklch(0.3 0.05 72))",
                  borderBottom: "1px solid var(--gold)",
                }}
              />
            </motion.div>

            {/* front pocket */}
            <div
              className="absolute inset-x-0 bottom-0 z-10 h-40"
              style={{
                clipPath: "polygon(0 100%, 0 30%, 50% 100%, 100% 30%, 100% 100%)",
                background: "linear-gradient(180deg, oklch(0.3 0.05 74), oklch(0.24 0.04 70))",
              }}
            />

            {/* wax seal */}
            <AnimatePresence>
              {!open && (
                <motion.div
                  exit={{ scale: 0, opacity: 0 }}
                  className="absolute left-1/2 top-1/2 z-40 flex h-12 w-12 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border-2 border-gold/60 bg-gold-deep text-primary-foreground gold-glow animate-pulse-glow"
                >
                  <HeartIcon />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* floating heart */}
        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ y: 0, opacity: 0, scale: 0.5 }}
              animate={{ y: -180, opacity: [0, 1, 0], scale: 1.4 }}
              transition={{ duration: 2.6, delay: 1.4, ease: "easeOut" }}
              className="pointer-events-none absolute left-1/2 top-1/2 z-50 -translate-x-1/2 text-gold gold-glow"
            >
              <HeartIcon big />
            </motion.div>
          )}
        </AnimatePresence>

        <motion.h2
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="mt-10 text-center font-serif text-xl text-gold-gradient"
        >
          {open ? "" : "A golden invitation awaits…"}
        </motion.h2>
      </div>

      {open && <ContinueHint label="click anywhere to fly forward" />}
    </button>
  )
}

function HeartIcon({ big }: { big?: boolean }) {
  const s = big ? 44 : 20
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 21s-7.5-4.9-10-9.3C.5 8.3 2 5 5.2 5c2 0 3.2 1.2 3.9 2.4C9.8 6.2 11 5 13 5c3.2 0 4.7 3.3 3.2 6.7C18.5 16.1 12 21 12 21z" />
    </svg>
  )
}
