"use client"

import { useState, useRef } from "react"
import { motion, AnimatePresence } from "motion/react"
import { GoldenParticles } from "@/components/golden-particles"
import { ContinueHint } from "@/components/continue-hint"

type FloatingLantern = { id: number; left: number }

export function StepLantern({ onComplete }: { onComplete: () => void }) {
  const [fill, setFill] = useState(0)
  const [holding, setHolding] = useState(false)
  const [released, setReleased] = useState(false)
  const [floaters, setFloaters] = useState<FloatingLantern[]>([])
  const raf = useRef<number | null>(null)

  const startHold = () => {
    if (released) return
    setHolding(true)
    const tick = () => {
      setFill((f) => {
        const next = Math.min(100, f + 1.6)
        return next
      })
      raf.current = requestAnimationFrame(tick)
    }
    raf.current = requestAnimationFrame(tick)
  }

  const endHold = () => {
    if (released) return
    setHolding(false)
    if (raf.current) cancelAnimationFrame(raf.current)
    setFill((f) => {
      if (f >= 60) {
        release()
        return 100
      }
      return f
    })
  }

  const release = () => {
    setReleased(true)
    // ambient lanterns joining the sky
    const others = Array.from({ length: 14 }).map((_, i) => ({
      id: i,
      left: 5 + Math.random() * 90,
    }))
    setFloaters([{ id: -1, left: 50 }, ...others])
    setTimeout(onComplete, 7000)
  }

  return (
    <div
      className="relative flex min-h-dvh w-full items-center justify-center overflow-hidden vignette no-select"
      style={{
        background:
          "linear-gradient(180deg, oklch(0.32 0.07 300) 0%, oklch(0.38 0.08 60) 55%, oklch(0.55 0.1 70) 100%)",
      }}
    >
      <GoldenParticles count={18} />

      {/* floating lanterns rising */}
      <AnimatePresence>
        {floaters.map((l) => (
          <motion.div
            key={l.id}
            className="pointer-events-none absolute bottom-0"
            style={{ left: `${l.left}%` }}
            initial={{ y: 0, opacity: 0 }}
            animate={{ y: "-110vh", opacity: [0, 1, 1, 0.7] }}
            transition={{ duration: 6 + Math.random() * 3, delay: l.id === -1 ? 0 : Math.random() * 2.5, ease: "easeOut" }}
          >
            <Lantern glow size={l.id === -1 ? 70 : 36 + Math.random() * 26} />
          </motion.div>
        ))}
      </AnimatePresence>

      <div className="relative z-10 flex flex-col items-center px-6 text-center">
        {!released ? (
          <>
            <h2 className="mb-2 font-serif text-2xl text-gold-gradient">Make a wish</h2>
            <p className="mb-8 text-sm italic text-[oklch(0.9_0.05_90)]">
              Hold to fill your lantern with love…
            </p>

            <motion.button
              onPointerDown={startHold}
              onPointerUp={endHold}
              onPointerLeave={endHold}
              animate={{ y: [0, -8, 0] }}
              transition={{ y: { duration: 3, repeat: Number.POSITIVE_INFINITY } }}
              className="relative cursor-pointer"
              aria-label="Hold to fill the lantern"
            >
              <Lantern fill={fill} glow={fill > 0} size={130} />
            </motion.button>

            {/* fill meter */}
            <div className="mt-8 h-2 w-52 overflow-hidden rounded-full bg-black/30">
              <motion.div
                className="h-full rounded-full bg-gold"
                style={{ width: `${fill}%`, boxShadow: "0 0 12px var(--gold)" }}
              />
            </div>
            <p className="mt-3 text-xs uppercase tracking-[0.3em] text-gold-soft/80">
              {holding ? "filling…" : fill > 0 ? "keep holding, then release" : "press & hold"}
            </p>
          </>
        ) : (
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 1.2 }}
            className="max-w-md text-balance font-serif text-xl leading-relaxed text-gold-gradient gold-glow"
          >
            Every lantern is a wish someone made for you. Now the sky is fuller. Like my heart when I
            think of you, Jaanu.
          </motion.p>
        )}
      </div>

      {released && <ContinueHint label="drift onward" />}
    </div>
  )
}

function Lantern({
  size = 120,
  fill = 100,
  glow = false,
}: {
  size?: number
  fill?: number
  glow?: boolean
}) {
  const intensity = fill / 100
  return (
    <div className="relative" style={{ width: size, height: size * 1.25 }}>
      {glow && (
        <div
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full blur-2xl"
          style={{
            width: size * 1.4,
            height: size * 1.4,
            background: "radial-gradient(circle, var(--gold-soft), transparent 70%)",
            opacity: 0.3 + intensity * 0.6,
          }}
        />
      )}
      <svg viewBox="0 0 100 125" width={size} height={size * 1.25} className="relative">
        {/* top cap */}
        <rect x="34" y="6" width="32" height="8" rx="3" fill="var(--gold-deep)" />
        {/* body */}
        <path
          d="M28 18 Q50 10 72 18 L72 96 Q50 108 28 96 Z"
          fill="oklch(0.85 0.12 75 / 0.25)"
          stroke="var(--gold)"
          strokeWidth="2.5"
        />
        {/* inner glow grows with fill */}
        <motion.ellipse
          cx="50"
          cy="62"
          rx="18"
          ry="28"
          fill="var(--gold-soft)"
          animate={{ opacity: 0.2 + intensity * 0.8 }}
          style={{ filter: "blur(6px)" }}
        />
        {/* flame */}
        {fill > 10 && (
          <motion.path
            d="M50 70 Q44 58 50 48 Q56 58 50 70 Z"
            fill="oklch(0.95 0.13 90)"
            animate={{ scaleY: [1, 1.2, 1], opacity: [0.7, 1, 0.7] }}
            transition={{ duration: 0.8, repeat: Number.POSITIVE_INFINITY }}
            style={{ transformOrigin: "50px 70px" }}
          />
        )}
        {/* bottom */}
        <rect x="34" y="98" width="32" height="7" rx="3" fill="var(--gold-deep)" />
      </svg>
    </div>
  )
}
