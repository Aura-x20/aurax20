"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "motion/react"
import { Typewriter } from "@/components/typewriter"
import { SparkleBurst } from "@/components/sparkle-burst"
import { ContinueHint } from "@/components/continue-hint"

const LINES = [
  "13/06.",
  "Today is not just a birthday, Jaanu.",
  "Today is proof that magic exists.",
  "And you? You are the magic.",
]

export function StepGate({ onComplete }: { onComplete: () => void }) {
  const [phase, setPhase] = useState<"gate" | "flash" | "text">("gate")
  const [textDone, setTextDone] = useState(false)

  useEffect(() => {
    if (phase === "flash") {
      const t = setTimeout(() => setPhase("text"), 900)
      return () => clearTimeout(t)
    }
  }, [phase])

  return (
    <div className="relative flex min-h-dvh w-full items-center justify-center overflow-hidden bg-background vignette">
      <AnimatePresence mode="wait">
        {phase === "gate" && (
          <motion.button
            key="gate"
            exit={{ opacity: 0 }}
            onClick={() => setPhase("flash")}
            className="relative flex h-full w-full cursor-pointer items-center justify-center no-select"
            aria-label="Fly through the golden gate"
          >
            {/* pulsing light behind gate */}
            <div className="absolute h-80 w-80 animate-pulse-glow rounded-full bg-gold/40 blur-3xl" />

            <motion.div
              animate={{ scale: [1, 1.04, 1] }}
              transition={{ duration: 2.5, repeat: Number.POSITIVE_INFINITY }}
              className="relative z-10"
            >
              <Gate />
            </motion.div>

            <p className="absolute bottom-24 text-sm uppercase tracking-[0.3em] text-gold-soft/80 animate-pulse">
              click to fly through
            </p>
          </motion.button>
        )}

        {phase === "flash" && (
          <motion.div
            key="flash"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 1, 1, 0.85] }}
            transition={{ duration: 0.9 }}
            className="absolute inset-0 z-50 bg-[oklch(0.97_0.1_92)]"
          />
        )}

        {phase === "text" && (
          <motion.div
            key="text"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="relative z-10 flex flex-col items-center px-6 text-center"
          >
            {textDone && <SparkleBurst count={36} />}
            <Typewriter
              lines={LINES}
              className="flex flex-col gap-3"
              lineClassName="text-balance font-serif text-2xl text-gold-gradient gold-glow md:text-3xl"
              onDone={() => setTextDone(true)}
            />

            <AnimatePresence>
              {textDone && (
                <motion.button
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.96 }}
                  onClick={onComplete}
                  className="mt-8 rounded-full border border-gold/50 bg-card/60 px-7 py-2.5 text-sm uppercase tracking-[0.25em] text-gold transition-colors hover:bg-card"
                >
                  continue
                </motion.button>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>

      {/* golden confetti */}
      {phase === "text" && textDone && <Confetti />}
      {phase === "text" && textDone && <ContinueHint label="release a wish next" />}
    </div>
  )
}

function Gate() {
  return (
    <svg width="220" height="300" viewBox="0 0 220 300" fill="none">
      <defs>
        <linearGradient id="gateGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="oklch(0.95 0.1 92)" />
          <stop offset="100%" stopColor="oklch(0.55 0.12 70)" />
        </linearGradient>
      </defs>
      {/* arch */}
      <path
        d="M30 290 V120 a80 80 0 0 1 160 0 V290"
        stroke="url(#gateGrad)"
        strokeWidth="10"
        fill="none"
        style={{ filter: "drop-shadow(0 0 14px var(--gold))" }}
      />
      {/* pillars detailing */}
      <rect x="22" y="120" width="18" height="170" rx="4" fill="url(#gateGrad)" />
      <rect x="180" y="120" width="18" height="170" rx="4" fill="url(#gateGrad)" />
      {/* finials */}
      <circle cx="31" cy="112" r="9" fill="url(#gateGrad)" />
      <circle cx="189" cy="112" r="9" fill="url(#gateGrad)" />
      {/* gate bars */}
      {[60, 85, 110, 135, 160].map((x) => (
        <line key={x} x1={x} y1="150" x2={x} y2="290" stroke="var(--gold)" strokeWidth="3" opacity="0.6" />
      ))}
    </svg>
  )
}

function Confetti() {
  return (
    <div className="pointer-events-none absolute inset-0 z-40 overflow-hidden">
      {Array.from({ length: 40 }).map((_, i) => {
        const left = Math.random() * 100
        const delay = Math.random() * 0.8
        const dur = 2.4 + Math.random() * 2
        const w = 5 + Math.random() * 5
        return (
          <motion.span
            key={i}
            className="absolute top-0 rounded-sm bg-gold"
            style={{ left: `${left}%`, width: w, height: w * 1.6, boxShadow: "0 0 6px var(--gold)" }}
            initial={{ y: -20, opacity: 0, rotate: 0 }}
            animate={{ y: "105vh", opacity: [0, 1, 1, 0], rotate: 360 }}
            transition={{ duration: dur, delay, ease: "easeIn" }}
          />
        )
      })}
    </div>
  )
}
