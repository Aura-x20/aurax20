"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "motion/react"
import { Bird } from "@/components/bird"
import { GoldenParticles } from "@/components/golden-particles"
import { ContinueHint } from "@/components/continue-hint"

const CHOICES = [
  { key: "soft", label: "Soft", icon: "🌸", msg: "You are gentleness in a loud world. Never change, Jaanu." },
  { key: "passionate", label: "Passionate", icon: "🔥", msg: "Loving you, Jaanu, is like breathing — I just do." },
  { key: "playful", label: "Playful", icon: "😊", msg: "Jaanu, you still make me smile like a kid with a secret." },
  { key: "deep", label: "Deep", icon: "🌙", msg: "Some people are chapters. You're the whole library, Jaanu." },
]

export function StepLake({ onComplete }: { onComplete: () => void }) {
  const [rippled, setRippled] = useState(false)
  const [choice, setChoice] = useState<(typeof CHOICES)[number] | null>(null)
  const [showExtra, setShowExtra] = useState(false)

  const pick = (c: (typeof CHOICES)[number]) => {
    setChoice(c)
    setTimeout(() => setShowExtra(true), 3200)
  }

  return (
    <div
      className="relative flex min-h-dvh w-full flex-col items-center justify-center overflow-hidden vignette"
      style={{
        background:
          "linear-gradient(180deg, oklch(0.28 0.05 150) 0%, oklch(0.24 0.05 140) 45%, oklch(0.2 0.06 200) 100%)",
      }}
    >
      <GoldenParticles count={16} />

      {/* misty trees */}
      <Trees />

      {/* mist */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{ background: "radial-gradient(ellipse at 50% 30%, oklch(0.6 0.04 150 / 0.25), transparent 60%)" }}
      />

      {/* bird on a branch */}
      <motion.div
        initial={{ y: -120, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1.4, ease: "easeOut" }}
        className="absolute left-8 top-24 z-10 flex flex-col items-center"
      >
        <Bird size={56} />
        <div className="mt-1 h-1.5 w-28 rounded-full bg-[oklch(0.3_0.05_60)]" />
      </motion.div>

      <div className="relative z-20 mb-4 px-6 text-center">
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="font-serif text-xl italic text-gold-soft"
        >
          Look into the water, Jaanu…
        </motion.p>
      </div>

      {/* lake */}
      <div className="relative z-10 w-full max-w-2xl px-4">
        <button
          onClick={() => setRippled(true)}
          disabled={rippled}
          className="relative mx-auto block h-56 w-full max-w-xl overflow-hidden rounded-[50%] no-select"
          style={{
            background:
              "radial-gradient(ellipse at 50% 40%, oklch(0.4 0.06 200 / 0.8), oklch(0.22 0.06 220 / 0.95))",
            boxShadow: "inset 0 0 60px oklch(0.1 0.04 220 / 0.8), 0 0 40px -10px var(--gold)",
            cursor: rippled ? "default" : "pointer",
          }}
          aria-label="Look into the lake"
        >
          {/* ripples */}
          <AnimatePresence>
            {rippled && (
              <>
                {[0, 1, 2].map((i) => (
                  <motion.span
                    key={i}
                    className="absolute left-1/2 top-1/2 h-10 w-32 -translate-x-1/2 -translate-y-1/2 rounded-[50%] border border-gold/50"
                    initial={{ scale: 0.2, opacity: 0.8 }}
                    animate={{ scale: 3.5, opacity: 0 }}
                    transition={{ duration: 2.4, delay: i * 0.5, repeat: Number.POSITIVE_INFINITY }}
                  />
                ))}
              </>
            )}
          </AnimatePresence>

          {/* reflected message */}
          <AnimatePresence>
            {choice && (
              <motion.p
                key={choice.key}
                initial={{ opacity: 0, scaleY: -1, y: 10 }}
                animate={{ opacity: [0, 1, 1, 0], scaleY: -1 }}
                transition={{ duration: 3.2, times: [0, 0.2, 0.75, 1] }}
                className="absolute inset-0 flex items-center justify-center px-8 text-center font-serif text-lg text-gold-soft"
              >
                {choice.msg}
              </motion.p>
            )}
          </AnimatePresence>

          {!rippled && (
            <span className="absolute inset-0 flex items-center justify-center text-sm uppercase tracking-[0.3em] text-gold-soft/70 animate-pulse">
              tap the water
            </span>
          )}
        </button>
      </div>

      {/* choice menu */}
      <AnimatePresence>
        {rippled && !choice && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="relative z-20 mt-8 grid w-full max-w-md grid-cols-2 gap-3 px-6"
          >
            {CHOICES.map((c) => (
              <motion.button
                key={c.key}
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => pick(c)}
                className="flex items-center justify-center gap-2 rounded-full border border-gold/50 bg-card/70 px-4 py-3 text-sm text-gold backdrop-blur-sm transition-colors hover:bg-card"
              >
                <span aria-hidden>{c.icon}</span>
                {c.label}
              </motion.button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* extra line + continue */}
      <AnimatePresence>
        {showExtra && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative z-20 mt-6 flex flex-col items-center px-6 text-center"
          >
            <p className="max-w-sm text-balance font-serif text-lg text-gold-gradient gold-glow">
              That&apos;s what I see when I look at you. Always.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.96 }}
              onClick={onComplete}
              className="mt-5 rounded-full border border-gold/50 bg-card/60 px-7 py-2.5 text-sm uppercase tracking-[0.25em] text-gold transition-colors hover:bg-card"
            >
              follow the bird
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>

      {showExtra && <ContinueHint label="to the nest" />}
    </div>
  )
}

function Trees() {
  return (
    <div className="pointer-events-none absolute inset-x-0 top-0 z-0 flex justify-between opacity-70">
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <svg key={i} width="120" height="280" viewBox="0 0 120 280" className="-mt-6">
          <rect x="54" y="120" width="12" height="160" fill="oklch(0.22 0.04 60)" />
          <ellipse cx="60" cy="90" rx="55" ry="70" fill={`oklch(0.3 0.07 ${130 + i * 8} / 0.85)`} />
          <ellipse cx="40" cy="120" rx="35" ry="48" fill="oklch(0.26 0.06 140 / 0.8)" />
          <ellipse cx="82" cy="118" rx="34" ry="46" fill="oklch(0.28 0.06 150 / 0.8)" />
        </svg>
      ))}
    </div>
  )
}
