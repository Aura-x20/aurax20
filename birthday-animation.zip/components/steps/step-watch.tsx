"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "motion/react"
import { GoldenParticles } from "@/components/golden-particles"

export function StepWatch({ onComplete }: { onComplete: () => void }) {
  const [open, setOpen] = useState(false)

  const handleOpen = () => {
    if (open) return
    setOpen(true)
    // watch closes automatically and flight continues
    setTimeout(() => setOpen(false), 4600)
    setTimeout(onComplete, 5600)
  }

  return (
    <div
      className="relative flex min-h-dvh w-full items-center justify-center overflow-hidden vignette"
      style={{
        background:
          "linear-gradient(180deg, oklch(0.5 0.07 78), oklch(0.34 0.05 72) 60%, oklch(0.22 0.03 68))",
      }}
    >
      <GoldenParticles count={22} />

      <div className="relative z-10 flex flex-col items-center px-6 text-center">
        <p className="mb-8 font-serif text-lg italic text-[oklch(0.95_0.04_92)]">
          A watch floats among the clouds, ticking softly…
        </p>

        <motion.button
          onClick={handleOpen}
          whileHover={{ scale: open ? 1 : 1.05 }}
          whileTap={{ scale: 0.97 }}
          animate={{ y: [0, -12, 0] }}
          transition={{ y: { duration: 4, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" } }}
          className="relative cursor-pointer"
          aria-label="Open the pocket watch"
        >
          {/* chain ring */}
          <div className="mx-auto mb-1 h-5 w-5 rounded-full border-[3px] border-gold/70" />

          <div className="relative h-56 w-56">
            {/* watch base / dial */}
            <div
              className="absolute inset-0 rounded-full border-[6px] shadow-[0_0_50px_-5px_var(--gold)]"
              style={{
                borderColor: "var(--gold)",
                background:
                  "radial-gradient(circle at 50% 40%, oklch(0.32 0.04 75), oklch(0.2 0.03 68))",
              }}
            >
              {/* dial face / stars */}
              <AnimatePresence>
                {open && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-3 flex flex-col items-center justify-center gap-2 rounded-full"
                  >
                    <SpinningStars />
                    <motion.span
                      initial={{ opacity: 0, scale: 0.5 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.6 }}
                      className="font-serif text-3xl font-semibold text-gold-gradient gold-glow"
                    >
                      13/06
                    </motion.span>
                    <motion.span
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 1.2 }}
                      className="max-w-[10rem] text-balance text-xs leading-relaxed text-gold-soft"
                    >
                      The day time stood still — because you were born.
                    </motion.span>
                  </motion.div>
                )}
              </AnimatePresence>

              {!open && <ClockFace />}
            </div>

            {/* lid */}
            <motion.div
              initial={false}
              animate={open ? { rotateY: -160 } : { rotateY: 0 }}
              transition={{ duration: 0.9, ease: "easeInOut" }}
              style={{ transformOrigin: "left center", transformStyle: "preserve-3d" }}
              className="absolute inset-0 rounded-full border-[6px] backface-hidden"
            >
              <div
                className="flex h-full w-full items-center justify-center rounded-full border-[6px]"
                style={{
                  borderColor: "var(--gold)",
                  background:
                    "radial-gradient(circle at 35% 30%, oklch(0.7 0.13 85), oklch(0.45 0.1 72))",
                }}
              >
                <div className="h-32 w-32 rounded-full border-2 border-gold-soft/50 opacity-70" />
                <span className="absolute font-script text-2xl text-[oklch(0.25_0.04_60)]">J</span>
              </div>
            </motion.div>
          </div>
        </motion.button>

        {!open && (
          <p className="mt-8 text-sm uppercase tracking-[0.3em] text-gold-soft/80 animate-pulse">
            click the watch
          </p>
        )}
      </div>
    </div>
  )
}

function ClockFace() {
  return (
    <div className="absolute inset-0 flex items-center justify-center">
      <div className="relative h-40 w-40 rounded-full">
        {Array.from({ length: 12 }).map((_, i) => (
          <span
            key={i}
            className="absolute left-1/2 top-1/2 h-2 w-0.5 -translate-x-1/2 bg-gold/70"
            style={{ transform: `rotate(${i * 30}deg) translateY(-72px)` }}
          />
        ))}
        {/* hands */}
        <motion.span
          className="absolute bottom-1/2 left-1/2 h-12 w-1 origin-bottom -translate-x-1/2 rounded bg-gold"
          animate={{ rotate: 360 }}
          transition={{ duration: 8, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
        />
        <motion.span
          className="absolute bottom-1/2 left-1/2 h-16 w-0.5 origin-bottom -translate-x-1/2 rounded bg-gold-soft"
          animate={{ rotate: 360 }}
          transition={{ duration: 2.5, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
        />
        <span className="absolute left-1/2 top-1/2 h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gold" />
      </div>
    </div>
  )
}

function SpinningStars() {
  return (
    <div className="pointer-events-none absolute inset-0">
      {Array.from({ length: 10 }).map((_, i) => (
        <motion.span
          key={i}
          className="absolute left-1/2 top-1/2 text-gold"
          initial={{ opacity: 0 }}
          animate={{
            opacity: [0, 1, 0.4],
            rotate: 360,
            x: Math.cos((i / 10) * Math.PI * 2) * 80,
            y: Math.sin((i / 10) * Math.PI * 2) * 80,
          }}
          transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, delay: i * 0.08 }}
        >
          <Star />
        </motion.span>
      ))}
    </div>
  )
}

function Star() {
  return (
    <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 2l2.4 6.9H22l-6 4.4 2.3 7-6.3-4.5L5.7 20.3 8 13.3 2 8.9h7.6z" />
    </svg>
  )
}
