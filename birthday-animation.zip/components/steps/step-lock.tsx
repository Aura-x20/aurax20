"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "motion/react"
import { GoldenParticles } from "@/components/golden-particles"
import { SparkleBurst } from "@/components/sparkle-burst"

const PASSCODE = "1306"

export function StepLock({ onComplete }: { onComplete: () => void }) {
  const [entry, setEntry] = useState("")
  const [error, setError] = useState(false)
  const [success, setSuccess] = useState(false)

  const press = (n: string) => {
    if (success) return
    setError(false)
    const next = (entry + n).slice(0, 4)
    setEntry(next)
    if (next.length === 4) {
      if (next === PASSCODE) {
        setSuccess(true)
        setTimeout(onComplete, 1700)
      } else {
        setTimeout(() => {
          setError(true)
          setEntry("")
        }, 220)
      }
    }
  }

  const del = () => {
    if (success) return
    setError(false)
    setEntry((e) => e.slice(0, -1))
  }

  return (
    <div className="relative flex min-h-dvh w-full items-center justify-center overflow-hidden bg-background vignette">
      <GoldenParticles count={28} />
      {success && <SparkleBurst count={40} />}

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: success ? 0 : 1, y: 0, scale: success ? 1.1 : 1 }}
        transition={{ duration: 0.8 }}
        className="relative z-10 flex w-full max-w-xs flex-col items-center px-6 text-center"
      >
        <motion.div
          animate={{ rotate: [0, 0], scale: [1, 1.04, 1] }}
          transition={{ duration: 3.5, repeat: Number.POSITIVE_INFINITY }}
          className="mb-6 flex h-16 w-16 items-center justify-center rounded-full border border-gold/50 bg-card/60 text-2xl text-gold gold-glow"
        >
          <LockMark />
        </motion.div>

        <h1 className="text-balance font-serif text-2xl font-medium text-gold-gradient">
          Enter the key to begin…
        </h1>

        {/* dots */}
        <div className="mt-7 mb-2 flex gap-3">
          {[0, 1, 2, 3].map((i) => (
            <motion.span
              key={i}
              animate={error ? { x: [0, -6, 6, -4, 4, 0] } : {}}
              transition={{ duration: 0.4 }}
              className={`h-3.5 w-3.5 rounded-full border transition-colors ${
                entry.length > i
                  ? "border-gold bg-gold shadow-[0_0_10px_var(--gold)]"
                  : "border-gold/40 bg-transparent"
              }`}
            />
          ))}
        </div>

        <div className="h-6">
          <AnimatePresence mode="wait">
            {error && (
              <motion.p
                key="err"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="text-sm italic text-gold-soft/80"
              >
                Not yet… try again
              </motion.p>
            )}
          </AnimatePresence>
        </div>

        {/* keypad */}
        <div className="mt-4 grid grid-cols-3 gap-3">
          {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((n) => (
            <KeyBtn key={n} onClick={() => press(n)}>
              {n}
            </KeyBtn>
          ))}
          <KeyBtn onClick={del} muted>
            ⌫
          </KeyBtn>
          <KeyBtn onClick={() => press("0")}>0</KeyBtn>
          <span />
        </div>
      </motion.div>

      {success && (
        <motion.p
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: [0, 1, 0], scale: 1.2 }}
          transition={{ duration: 1.7 }}
          className="absolute z-20 font-script text-3xl text-gold-gradient gold-glow"
        >
          Welcome, Jaanu…
        </motion.p>
      )}
    </div>
  )
}

function KeyBtn({
  children,
  onClick,
  muted,
}: {
  children: React.ReactNode
  onClick: () => void
  muted?: boolean
}) {
  return (
    <motion.button
      whileTap={{ scale: 0.9 }}
      onClick={onClick}
      className={`flex h-14 w-14 items-center justify-center rounded-full border border-gold/30 bg-card/50 text-lg backdrop-blur-sm transition-colors hover:border-gold/70 hover:bg-card ${
        muted ? "text-gold-soft/60" : "text-foreground"
      }`}
    >
      {children}
    </motion.button>
  )
}

function LockMark() {
  return (
    <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
      <rect x="4" y="10" width="16" height="11" rx="3" stroke="currentColor" strokeWidth="1.6" />
      <path d="M8 10V7a4 4 0 0 1 8 0v3" stroke="currentColor" strokeWidth="1.6" />
      <circle cx="12" cy="15" r="1.6" fill="currentColor" />
    </svg>
  )
}
