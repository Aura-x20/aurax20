"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "motion/react"
import { GoldenParticles } from "@/components/golden-particles"
import { Bird } from "@/components/bird"
import { ContinueHint } from "@/components/continue-hint"

const FRAMES = [
  "The time you laughed so hard tea came out of your nose",
  "When you pretended to be angry but smiled in 2 seconds",
  "Every single day you made ordinary feel like a movie",
]

export function StepHall({ onComplete }: { onComplete: () => void }) {
  const [revealed, setRevealed] = useState<number[]>([])
  const allRevealed = revealed.length === FRAMES.length

  const reveal = (i: number) =>
    setRevealed((r) => (r.includes(i) ? r : [...r, i]))

  return (
    <div className="relative flex min-h-dvh w-full flex-col items-center justify-center overflow-hidden bg-gradient-to-b from-[oklch(0.2_0.03_72)] to-background px-4 vignette">
      <GoldenParticles count={24} />

      {/* hallway perspective glow */}
      <div
        className="pointer-events-none absolute inset-0 opacity-60"
        style={{
          background:
            "radial-gradient(ellipse at 50% 45%, oklch(0.4 0.1 82 / 0.5), transparent 55%)",
        }}
      />

      <motion.h2
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 mb-2 text-center font-serif text-2xl text-gold-gradient"
      >
        Hall of Golden Memories
      </motion.h2>
      <p className="relative z-10 mb-6 text-center text-sm italic text-muted-foreground">
        Tap each frame to remember…
      </p>

      {/* flying bird across hallway */}
      <motion.div
        initial={{ x: "-30vw", y: -40 }}
        animate={{ x: "30vw", y: -40 }}
        transition={{ duration: 6, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut", repeatType: "reverse" }}
        className="pointer-events-none absolute top-24 z-10"
      >
        <Bird size={48} />
      </motion.div>

      <div className="relative z-10 grid w-full max-w-3xl grid-cols-1 gap-4 md:grid-cols-3">
        {FRAMES.map((text, i) => (
          <Frame key={i} index={i} text={text} open={revealed.includes(i)} onReveal={() => reveal(i)} />
        ))}
      </div>

      <AnimatePresence>
        {allRevealed && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="relative z-10 mt-8 flex flex-col items-center text-center"
          >
            <p className="max-w-md text-balance font-serif text-lg text-gold-gradient gold-glow">
              These are mine. But my favorite? Whatever comes next with you.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.96 }}
              onClick={onComplete}
              className="mt-5 rounded-full border border-gold/50 bg-card/60 px-7 py-2.5 text-sm uppercase tracking-[0.25em] text-gold transition-colors hover:bg-card"
            >
              fly onward
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>

      {allRevealed && <ContinueHint label="follow the bird" />}
    </div>
  )
}

function Frame({
  index,
  text,
  open,
  onReveal,
}: {
  index: number
  text: string
  open: boolean
  onReveal: () => void
}) {
  return (
    <motion.button
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.15 * index }}
      onClick={onReveal}
      whileHover={{ scale: open ? 1 : 1.03 }}
      className="group relative flex aspect-[3/4] w-full items-center justify-center overflow-hidden rounded-lg p-4 text-center animate-floaty-slow"
      style={{
        animationDelay: `${index * 1.2}s`,
        border: "3px solid transparent",
        background:
          "linear-gradient(oklch(0.22 0.03 70), oklch(0.18 0.025 68)) padding-box, linear-gradient(145deg, var(--gold-soft), var(--gold-deep)) border-box",
        boxShadow: "0 0 30px -8px var(--gold)",
      }}
    >
      <AnimatePresence mode="wait">
        {open ? (
          <motion.p
            key="text"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="font-serif text-base leading-relaxed text-foreground"
          >
            {text}
          </motion.p>
        ) : (
          <motion.div
            key="icon"
            exit={{ opacity: 0, scale: 0.5 }}
            className="flex flex-col items-center gap-2 text-gold/70"
          >
            <PortraitIcon />
            <span className="text-xs uppercase tracking-widest text-gold/50">memory {index + 1}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.button>
  )
}

function PortraitIcon() {
  return (
    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4">
      <circle cx="12" cy="9" r="3.2" />
      <path d="M5 19c1.2-3.5 4-5 7-5s5.8 1.5 7 5" />
    </svg>
  )
}
