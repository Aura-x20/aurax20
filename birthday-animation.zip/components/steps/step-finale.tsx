"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "motion/react"
import { GoldenParticles } from "@/components/golden-particles"
import { SparkleBurst } from "@/components/sparkle-burst"

type Phase = "nest" | "letter" | "diary" | "egg" | "feather"

const LETTER = `Happy 13/06, my dearest Bubi.
Another trip around the sun — and somehow, you shine brighter.
This box doesn't just hold chocolate. It holds every 'good morning' I almost said, every laugh I saved for later, every quiet prayer that you'd stay.
You are my anniversary, my party, my golden sky, and my quiet lake.
Bubu, you are the reason I believe in forever.
I love you. Today. Tomorrow. And in every universe where we find each other again.
Yours, always.`

export function StepFinale({ onComplete }: { onComplete: () => void }) {
  const [phase, setPhase] = useState<Phase>("nest")
  const [boxOpen, setBoxOpen] = useState(false)
  const [glitch, setGlitch] = useState(false)

  const openBox = () => {
    setBoxOpen(true)
    setTimeout(() => setPhase("letter"), 900)
  }

  const openDiary = () => setPhase("diary")

  const crumbleDiary = () => {
    // diary crumbles into dust, reveal the egg hint via box lid
    setPhase("egg")
  }

  const triggerEgg = () => {
    setGlitch(true)
    setTimeout(() => setGlitch(false), 600)
  }

  return (
    <div
      className="relative flex min-h-dvh w-full items-center justify-center overflow-hidden vignette"
      style={{
        background:
          "radial-gradient(ellipse at 50% 40%, oklch(0.3 0.05 70), oklch(0.16 0.02 65) 75%)",
      }}
    >
      <GoldenParticles count={20} />

      <AnimatePresence>
        {glitch && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.9, 0, 0.6, 0] }}
            transition={{ duration: 0.6 }}
            className="absolute inset-0 z-50 mix-blend-screen"
            style={{ background: "repeating-linear-gradient(0deg, var(--gold) 0 2px, transparent 2px 6px)" }}
          />
        )}
      </AnimatePresence>

      <div className="relative z-10 flex w-full max-w-lg flex-col items-center px-6 text-center">
        {/* Tree hollow / nest is always present as the anchor */}
        <AnimatePresence mode="wait">
          {/* STEP 8: NEST + CHOCOLATE BOX (closed) */}
          {phase === "nest" && (
            <motion.div
              key="nest"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center"
            >
              <p className="mb-6 font-serif text-lg italic text-gold-soft">
                A cozy nest glows in the tree hollow…
              </p>
              <Nest>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.96 }}
                  onClick={openBox}
                  className="relative cursor-pointer"
                  aria-label="Open the chocolate box"
                >
                  <ChocolateBox open={boxOpen} />
                </motion.button>
              </Nest>
              <p className="mt-6 text-sm uppercase tracking-[0.3em] text-gold-soft/70 animate-pulse">
                tap the golden box
              </p>
            </motion.div>
          )}

          {/* STEP 8 cont: LETTER */}
          {phase === "letter" && (
            <motion.div
              key="letter"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.8 }}
              className="w-full"
            >
              <div className="rounded-lg border border-gold/40 bg-[oklch(0.95_0.03_92)] p-6 text-left shadow-[0_0_50px_-10px_var(--gold)]">
                {LETTER.split("\n").map((line, i) => (
                  <motion.p
                    key={i}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.3 + i * 0.5 }}
                    className={`font-serif leading-relaxed text-[oklch(0.3_0.05_55)] ${
                      i === 0 ? "mb-2 text-xl font-semibold" : "mb-2 text-base"
                    } ${i === LETTER.split("\n").length - 1 ? "mt-3 text-right font-script text-lg text-[oklch(0.45_0.12_55)]" : ""}`}
                  >
                    {line}
                  </motion.p>
                ))}
              </div>
              <motion.button
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 3.6 }}
                whileHover={{ scale: 1.05 }}
                onClick={openDiary}
                className="mt-5 inline-flex items-center gap-2 rounded-full border border-gold/50 bg-card/60 px-6 py-2.5 text-sm uppercase tracking-[0.2em] text-gold transition-colors hover:bg-card"
              >
                a corner peeks out…
              </motion.button>
            </motion.div>
          )}

          {/* STEP 9: DIARY PAGE */}
          {phase === "diary" && (
            <DiaryPage key="diary" onCrumble={crumbleDiary} />
          )}

          {/* STEP 10: EASTER EGG */}
          {phase === "egg" && (
            <EasterEgg key="egg" glitch={triggerEgg} onDone={() => setPhase("feather")} />
          )}

          {/* STEP 11: GOLDEN FEATHER */}
          {phase === "feather" && <Feather key="feather" onComplete={onComplete} />}
        </AnimatePresence>
      </div>
    </div>
  )
}

/* ---------- Step 9 ---------- */
function DiaryPage({ onCrumble }: { onCrumble: () => void }) {
  const [crumbling, setCrumbling] = useState(false)
  return (
    <motion.div
      initial={{ opacity: 0, rotate: -3, y: 30 }}
      animate={crumbling ? { opacity: 0, scale: 0.8, filter: "blur(8px)" } : { opacity: 1, rotate: -1.5, y: 0 }}
      transition={{ duration: crumbling ? 1.2 : 0.8 }}
      onAnimationComplete={() => crumbling && onCrumble()}
      className="relative w-full max-w-sm"
    >
      <div
        className="relative rounded-sm p-6 text-left shadow-xl"
        style={{
          background:
            "linear-gradient(135deg, oklch(0.88 0.04 85), oklch(0.82 0.05 80))",
          boxShadow: "inset 0 0 40px oklch(0.6 0.08 60 / 0.4)",
        }}
      >
        {/* coffee stain */}
        <div
          className="absolute right-4 top-4 h-16 w-16 rounded-full opacity-40"
          style={{ background: "radial-gradient(circle, oklch(0.45 0.07 60 / 0.7), transparent 70%)" }}
        />
        <p className="font-script text-lg leading-relaxed text-[oklch(0.3_0.06_45)]">
          Shh… don&apos;t tell anyone I wrote this.
          <br />
          But sometimes, when you&apos;re not looking, I stare at you and think —
          <br />
          <span className="italic">&ldquo;How did I get this lucky?&rdquo;</span>
          <br />
          You&apos;re my favorite thought, Jaanu. The first and the last of every day.
        </p>
      </div>
      {!crumbling && (
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.6 }}
          whileHover={{ scale: 1.05 }}
          onClick={() => setCrumbling(true)}
          className="mt-5 rounded-full border border-gold/50 bg-card/60 px-6 py-2.5 text-sm uppercase tracking-[0.2em] text-gold transition-colors hover:bg-card"
        >
          let it turn to dust
        </motion.button>
      )}
    </motion.div>
  )
}

/* ---------- Step 10 ---------- */
function EasterEgg({ glitch, onDone }: { glitch: () => void; onDone: () => void }) {
  const [cracked, setCracked] = useState(false)
  const [revealed, setRevealed] = useState(false)

  const handleClick = () => {
    glitch()
    setRevealed(true)
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="flex flex-col items-center"
    >
      {!revealed ? (
        <>
          <p className="mb-6 font-serif text-base italic text-gold-soft/80">
            …the box lid glints again. Tap it.
          </p>
          <motion.button whileTap={{ scale: 0.95 }} onClick={handleClick} aria-label="Tap the lid">
            <ChocolateBox open size={150} />
          </motion.button>
        </>
      ) : (
        <>
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="relative"
          >
            {!cracked ? (
              <motion.button
                whileTap={{ scale: 0.92 }}
                onClick={() => setCracked(true)}
                animate={{ rotate: [0, -2, 2, -2, 0] }}
                transition={{ duration: 0.4, repeat: Number.POSITIVE_INFINITY, repeatDelay: 1.5 }}
                aria-label="Crack the egg"
              >
                <Egg />
                <span className="mt-3 block text-xs uppercase tracking-[0.3em] text-gold-soft/70">
                  tap to crack
                </span>
              </motion.button>
            ) : (
              <div className="relative flex flex-col items-center">
                <SparkleBurst count={24} />
                <motion.div
                  initial={{ y: 0, opacity: 0, scale: 0.4 }}
                  animate={{ y: -120, opacity: [0, 1, 0], scale: 1.4 }}
                  transition={{ duration: 2.6 }}
                  className="text-gold gold-glow"
                >
                  <HeartIcon big />
                </motion.div>
              </div>
            )}
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-6 max-w-sm text-balance font-serif text-lg leading-relaxed text-gold-gradient gold-glow"
          >
            Psst… you found the secret egg, Gulab Jamun! 0_0
            <br />
            One wish. Close your eyes. Make it.
            <br />
            <span className="text-base italic text-gold-soft">
              (And yes — you&apos;re sweeter than actual gulab jamuns. Don&apos;t argue.)
            </span>
          </motion.p>

          {cracked && (
            <motion.button
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.8 }}
              whileHover={{ scale: 1.05 }}
              onClick={onDone}
              className="mt-6 rounded-full border border-gold/50 bg-card/60 px-6 py-2.5 text-sm uppercase tracking-[0.2em] text-gold transition-colors hover:bg-card"
            >
              one last gift…
            </motion.button>
          )}
        </>
      )}
    </motion.div>
  )
}

/* ---------- Step 11 ---------- */
function Feather({ onComplete }: { onComplete: () => void }) {
  const [dissolved, setDissolved] = useState(false)
  const [ended, setEnded] = useState(false)

  const click = () => {
    setDissolved(true)
    setTimeout(() => setEnded(true), 1600)
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-center">
      <AnimatePresence mode="wait">
        {!ended ? (
          <motion.div key="feather" exit={{ opacity: 0 }} className="flex flex-col items-center">
            {!dissolved ? (
              <motion.button
                onClick={click}
                initial={{ y: -200, rotate: -20, opacity: 0 }}
                animate={{ y: [-200, 0], rotate: [-20, 10, -6, 0], opacity: 1 }}
                transition={{ duration: 2.4, ease: "easeOut" }}
                whileHover={{ scale: 1.08 }}
                className="cursor-pointer"
                aria-label="Touch the golden feather"
              >
                <FeatherIcon />
              </motion.button>
            ) : (
              <div className="relative">
                <SparkleBurst count={30} />
                <FeatherIcon faded />
              </div>
            )}

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
              className="mt-8 max-w-md text-balance font-serif text-lg leading-relaxed text-gold-gradient gold-glow"
            >
              Come back to this sky anytime, Gulab Jamun.
              <br />
              The birds will remember you. And so will I.
              <br />
              Always your Jaanu. Always yours.
              <br />
              <span className="mt-3 block font-script text-2xl text-gold-soft">— Love, Your Dudu</span>
            </motion.p>

            {!dissolved && (
              <p className="mt-6 text-xs uppercase tracking-[0.3em] text-gold-soft/70 animate-pulse">
                touch the feather
              </p>
            )}
          </motion.div>
        ) : (
          <motion.div
            key="end"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.5 }}
            className="flex flex-col items-center"
          >
            <p className="text-balance font-serif text-2xl leading-relaxed text-gold-gradient gold-glow">
              The end… for now.
              <br />
              Come back anytime.
              <br />
              The sky remembers you.
            </p>
            <button
              onClick={onComplete}
              className="mt-8 rounded-full border border-gold/50 bg-card/60 px-7 py-2.5 text-sm uppercase tracking-[0.25em] text-gold transition-colors hover:bg-card"
            >
              replay the journey
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

/* ---------- Shared art ---------- */
function Nest({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative flex h-52 w-72 items-center justify-center">
      {/* hollow glow */}
      <div
        className="absolute inset-0 rounded-[50%] opacity-80"
        style={{ background: "radial-gradient(ellipse at 50% 60%, oklch(0.4 0.08 70 / 0.6), transparent 70%)" }}
      />
      {/* nest */}
      <svg viewBox="0 0 200 120" className="absolute bottom-0 w-full">
        {Array.from({ length: 14 }).map((_, i) => (
          <path
            key={i}
            d={`M${15 + i * 5} ${70 + (i % 3) * 6} Q100 ${110 + (i % 4) * 4} ${185 - i * 5} ${70 + (i % 3) * 6}`}
            stroke={`oklch(${0.4 - (i % 3) * 0.05} 0.06 60)`}
            strokeWidth="3"
            fill="none"
            opacity="0.9"
          />
        ))}
      </svg>
      <div className="relative z-10 mb-2">{children}</div>
    </div>
  )
}

function ChocolateBox({ open, size = 120 }: { open: boolean; size?: number }) {
  return (
    <div className="relative" style={{ width: size, height: size * 0.85 }}>
      {/* glow when open */}
      {open && (
        <div
          className="absolute left-1/2 top-0 -translate-x-1/2 rounded-full blur-2xl"
          style={{ width: size, height: size, background: "radial-gradient(circle, var(--gold-soft), transparent 70%)" }}
        />
      )}
      <svg viewBox="0 0 120 102" width={size} height={size * 0.85}>
        {/* base */}
        <rect x="16" y="46" width="88" height="50" rx="6" fill="var(--gold-deep)" stroke="var(--gold)" strokeWidth="2" />
        {/* chocolates */}
        {open &&
          [28, 48, 68, 88].map((x) => <circle key={x} cx={x} cy="64" r="6" fill="oklch(0.35 0.05 50)" />)}
        {/* lid */}
        <motion.g animate={open ? { y: -22, rotate: -8 } : { y: 0, rotate: 0 }} style={{ transformOrigin: "60px 46px" }}>
          <rect x="12" y="34" width="96" height="20" rx="5" fill="var(--gold)" stroke="var(--gold-soft)" strokeWidth="2" />
          {/* ribbon */}
          <rect x="54" y="34" width="12" height="20" fill="var(--gold-deep)" />
          <path d="M60 34 Q48 20 40 28 Q52 30 60 38 Q68 30 80 28 Q72 20 60 34Z" fill="var(--gold-soft)" />
        </motion.g>
      </svg>
    </div>
  )
}

function Egg() {
  return (
    <svg width="90" height="110" viewBox="0 0 90 110">
      <defs>
        <linearGradient id="eggGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="oklch(0.95 0.09 92)" />
          <stop offset="100%" stopColor="oklch(0.6 0.13 70)" />
        </linearGradient>
      </defs>
      <ellipse cx="45" cy="60" rx="38" ry="48" fill="url(#eggGrad)" stroke="var(--gold)" strokeWidth="2" />
      {[20, 40, 60, 80].map((y) => (
        <path key={y} d={`M10 ${y} Q45 ${y + 8} 80 ${y}`} stroke="var(--gold-deep)" strokeWidth="1.5" fill="none" opacity="0.5" />
      ))}
    </svg>
  )
}

function FeatherIcon({ faded }: { faded?: boolean }) {
  return (
    <svg width="70" height="160" viewBox="0 0 70 160" style={{ opacity: faded ? 0.3 : 1 }} className={faded ? "" : "animate-floaty"}>
      <defs>
        <linearGradient id="featherGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="oklch(0.96 0.09 92)" />
          <stop offset="100%" stopColor="oklch(0.6 0.13 68)" />
        </linearGradient>
      </defs>
      <path
        d="M35 6 C12 40 12 100 30 150 C40 110 58 50 35 6Z"
        fill="url(#featherGrad)"
        stroke="var(--gold)"
        strokeWidth="1.5"
        style={{ filter: "drop-shadow(0 0 10px var(--gold))" }}
      />
      <line x1="35" y1="14" x2="31" y2="150" stroke="var(--gold-deep)" strokeWidth="1.5" />
      {Array.from({ length: 12 }).map((_, i) => (
        <line
          key={i}
          x1="34"
          y1={26 + i * 10}
          x2={i % 2 === 0 ? 16 : 54}
          y2={20 + i * 10}
          stroke="var(--gold)"
          strokeWidth="0.8"
          opacity="0.6"
        />
      ))}
    </svg>
  )
}

function HeartIcon({ big }: { big?: boolean }) {
  const s = big ? 48 : 22
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 21s-7.5-4.9-10-9.3C.5 8.3 2 5 5.2 5c2 0 3.2 1.2 3.9 2.4C9.8 6.2 11 5 13 5c3.2 0 4.7 3.3 3.2 6.7C18.5 16.1 12 21 12 21z" />
    </svg>
  )
}
