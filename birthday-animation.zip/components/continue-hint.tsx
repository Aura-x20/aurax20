"use client"

import { motion } from "motion/react"

/** A gentle pulsing hint telling the user to continue. */
export function ContinueHint({ label = "click anywhere to continue" }: { label?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: [0.4, 1, 0.4] }}
      transition={{ duration: 2.4, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut", delay: 1 }}
      className="pointer-events-none absolute bottom-8 left-1/2 -translate-x-1/2 text-center text-xs uppercase tracking-[0.35em] text-gold-soft/80"
    >
      {label}
    </motion.div>
  )
}
