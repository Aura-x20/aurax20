"use client"

import { useState, useCallback } from "react"
import { AnimatePresence, motion } from "motion/react"
import { StepLock } from "@/components/steps/step-lock"
import { StepInvitation } from "@/components/steps/step-invitation"
import { StepHall } from "@/components/steps/step-hall"
import { StepClouds } from "@/components/steps/step-clouds"
import { StepWatch } from "@/components/steps/step-watch"
import { StepGate } from "@/components/steps/step-gate"
import { StepLantern } from "@/components/steps/step-lantern"
import { StepLake } from "@/components/steps/step-lake"
import { StepFinale } from "@/components/steps/step-finale"

export default function Page() {
  const [step, setStep] = useState(0)

  const next = useCallback(() => setStep((s) => s + 1), [])
  const restart = useCallback(() => setStep(0), [])

  const steps = [
    <StepLock key="lock" onComplete={next} />,
    <StepInvitation key="invitation" onComplete={next} />,
    <StepHall key="hall" onComplete={next} />,
    <StepClouds key="clouds" onComplete={next} />,
    <StepWatch key="watch" onComplete={next} />,
    <StepGate key="gate" onComplete={next} />,
    <StepLantern key="lantern" onComplete={next} />,
    <StepLake key="lake" onComplete={next} />,
    <StepFinale key="finale" onComplete={restart} />,
  ]

  return (
    <main className="relative min-h-dvh w-full bg-background">
      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          initial={{ opacity: 0, scale: 1.02 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.98 }}
          transition={{ duration: 0.7, ease: "easeInOut" }}
        >
          {steps[step]}
        </motion.div>
      </AnimatePresence>
    </main>
  )
}
